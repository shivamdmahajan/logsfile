<?php
session_start();

// Define database connection details for Amazon RDS
$servername = "10.0.3.65"; // RDS Endpoint
$username = "webuser"; // RDS Username
$password = "shivam123"; // RDS Password
$dbname = "user_accounts"; // Database Name

// Create a secure MySQL connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get user input (Sanitize to prevent SQL Injection)
$name    = trim($_POST['user']);
$fName   = trim($_POST['fname']);
$lName   = trim($_POST['lname']);
$Country = trim($_POST['country']);
$State   = trim($_POST['state']);
$pwd     = trim($_POST['password']);

// Check if the username already exists
$stmt = $connection->prepare("SELECT * FROM user WHERE username = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['error'] = "This Username ($name) has already been taken.";
    header('location:register.php');
    exit();
} else {
    // Hash the password before storing it
    $hashed_pwd = password_hash($pwd, PASSWORD_BCRYPT);

    // Insert the new user into the database
    $stmt = $connection->prepare("INSERT INTO user (username, fName, lName, state, country, password) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $fName, $lName, $State, $Country, $hashed_pwd);

    if ($stmt->execute()) {
        $_SESSION['success'] = "You have been successfully registered!";
        header('location:login.php');
        exit();
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
        header('location:register.php');
        exit();
    }
}

// Close connection
$stmt->close();
$connection->close();
?>
