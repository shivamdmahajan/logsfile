<?php
$servername = "10.0.3.157"; // Use private IP of MySQL server
$username = "root";  // Your MySQL username
$password = "ABhinay123$"; // Your MySQL password
$dbname = "user_accounts"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch users
$sql = "SELECT * FROM user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Username</th><th>First Name</th><th>Last Name</th><th>State</th><th>Country</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["username"]."</td><td>".$row["fName"]."</td><td>".$row["lName"]."</td><td>".$row["state"]."</td><td>".$row["country"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "No records found.";
}

$conn->close();
?>
