<?php
session_start();

// Define database connection details for Amazon RDS
$servername = "10.0.3.65"; // RDS Endpoint
$username = "webuser"; // RDS Username
$password = "shivam123"; // RDS Password
$dbname = "user_accounts"; // Database Name

// Create a secure MySQL connection
$connection = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Get user input (Sanitize to prevent SQL Injection)
$name = trim($_POST['user']);
$pwd  = trim($_POST['password']);

// Use prepared statements to prevent SQL Injection
$stmt = $connection->prepare("SELECT * FROM user WHERE username = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();

    // Verify password (assuming password is hashed in the database)
    if (password_verify($pwd, $row['password'])) {
        $_SESSION['username'] = $row['username'];
        $_SESSION['fName'] = $row['fName'];
        $_SESSION['lName'] = $row['lName'];
        $_SESSION['State'] = $row['state'];
        $_SESSION['Country'] = $row['country'];
        header('location:home.php');
        exit();
    } else {
        $_SESSION['error'] = "Login failed. Incorrect username or password.";
        header('location:login.php');
        exit();
    }
} else {
    $_SESSION['error'] = "Login failed. Incorrect username or password.";
    header('location:login.php');
    exit();
}

// Close connection
$stmt->close();
$connection->close();
?>
